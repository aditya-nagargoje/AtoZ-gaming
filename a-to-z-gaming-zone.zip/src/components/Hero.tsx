import { motion } from 'motion/react';
import { MessageCircle, Gamepad2, Zap } from 'lucide-react';

export default function Hero() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const openWhatsApp = () => {
    window.dispatchEvent(new CustomEvent('open-booking-modal'));
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-dark-bg pt-20">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid-pattern opacity-20"></div>
      
      {/* Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-blue/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-purple/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }}></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm"
        >
          <Zap className="w-4 h-4 text-neon-green" />
          <span className="text-sm font-medium text-gray-300 tracking-wide uppercase">FIFA • GTA V • Cricket 24 • Multiplayer Gaming</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-4xl md:text-6xl lg:text-7xl font-display font-black text-white mb-6 uppercase tracking-tighter"
        >
          Pune's Ultimate <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue via-neon-purple to-neon-red text-glow-blue">
            PS5 & PS4 Gaming Zone 🎮
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-12 font-light"
        >
          Play your favorite games with friends. Book your slot instantly and enjoy high-performance gaming in a comfortable AC setup.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center gap-6"
        >
          <button
            onClick={openWhatsApp}
            className="group relative px-8 py-4 bg-[#25D366] text-white font-display font-bold text-lg rounded-full uppercase tracking-wider overflow-hidden shadow-[0_0_15px_rgba(37,211,102,0.5)] w-full sm:w-auto hover:scale-105 transition-all duration-300"
          >
            <span className="relative flex items-center justify-center gap-2">
              <MessageCircle className="w-6 h-6" /> Book on WhatsApp
            </span>
          </button>

          <button
            onClick={() => scrollToSection('#pricing')}
            className="group px-8 py-4 bg-transparent border border-white/20 text-white font-display font-bold text-lg rounded-full uppercase tracking-wider hover:border-neon-blue hover:text-neon-blue transition-all duration-300 w-full sm:w-auto flex items-center justify-center gap-2"
          >
            <Gamepad2 className="w-5 h-5 group-hover:-rotate-12 transition-transform" />
            View Pricing
          </button>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer"
        onClick={() => scrollToSection('#about')}
      >
        <span className="text-xs text-gray-500 uppercase tracking-widest font-display">Scroll Down</span>
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="w-6 h-10 border-2 border-gray-500 rounded-full flex justify-center p-1"
        >
          <div className="w-1 h-2 bg-neon-blue rounded-full"></div>
        </motion.div>
      </motion.div>
    </section>
  );
}
