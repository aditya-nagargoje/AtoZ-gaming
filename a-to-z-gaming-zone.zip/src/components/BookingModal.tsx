import { useState, useEffect } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageCircle, ArrowLeft } from 'lucide-react';

export default function BookingModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState<'options' | 'sameday_form' | 'future_form'>('options');
  const [formData, setFormData] = useState({
    name: '',
    players: '',
    timeSlot: '',
    arrivalTime: '',
    date: ''
  });

  useEffect(() => {
    const handleOpen = () => {
      setIsOpen(true);
      setStep('options');
      setFormData({ name: '', players: '', timeSlot: '', arrivalTime: '', date: '' });
    };
    window.addEventListener('open-booking-modal', handleOpen);
    return () => window.removeEventListener('open-booking-modal', handleOpen);
  }, []);

  const handleClose = () => setIsOpen(false);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSameDaySubmit = (e: FormEvent) => {
    e.preventDefault();
    const text = `Aaj ka booking request aaya hai:\n\nNaam: ${formData.name}\nPlayers: ${formData.players}\nSlot: ${formData.timeSlot}\nArrival Time: ${formData.arrivalTime}\n\nAvailable hai kya? Confirm kare.`;
    window.open(`https://wa.me/917020569018?text=${encodeURIComponent(text)}`, '_blank');
    handleClose();
  };

  const handleFutureSubmit = (e: FormEvent) => {
    e.preventDefault();
    const text = `Advance booking request aaya hai:\n\nNaam: ${formData.name}\nDate: ${formData.date}\nSlot: ${formData.timeSlot}\nPlayers: ${formData.players}\n\nAdvance payment confirmation ka wait hai.`;
    window.open(`https://wa.me/917020569018?text=${encodeURIComponent(text)}`, '_blank');
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }} 
          onClick={handleClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }} 
          animate={{ opacity: 1, scale: 1, y: 0 }} 
          exit={{ opacity: 0, scale: 0.95, y: 20 }} 
          className="relative w-full max-w-md bg-dark-surface border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-10"
        >
          {/* Header */}
          <div className="bg-black/50 p-4 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {step !== 'options' && (
                <button onClick={() => setStep('options')} className="text-gray-400 hover:text-white transition-colors">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <h2 className="text-lg font-display font-bold text-white">Book Your Slot</h2>
            </div>
            <button onClick={handleClose} className="text-gray-400 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6">
            {step === 'options' && (
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                <div className="mb-6">
                  <h3 className="text-xl font-display font-bold text-white mb-2">Namaste 👋</h3>
                  <p className="text-gray-400">Booking ke liye option select kare:</p>
                </div>
                <button onClick={() => setStep('sameday_form')} className="w-full p-4 bg-black border border-white/10 rounded-xl hover:border-neon-blue hover:bg-neon-blue/10 text-left transition-all group">
                  <span className="text-xl mr-3">1️⃣</span>
                  <span className="text-gray-300 group-hover:text-white font-medium">Same Day Booking <span className="text-gray-500 text-sm block mt-1">(Aaj ke liye)</span></span>
                </button>
                <button onClick={() => setStep('future_form')} className="w-full p-4 bg-black border border-white/10 rounded-xl hover:border-neon-purple hover:bg-neon-purple/10 text-left transition-all group">
                  <span className="text-xl mr-3">2️⃣</span>
                  <span className="text-gray-300 group-hover:text-white font-medium">Next Day Booking <span className="text-gray-500 text-sm block mt-1">(Kal ke liye)</span></span>
                </button>
                <button onClick={() => setStep('future_form')} className="w-full p-4 bg-black border border-white/10 rounded-xl hover:border-neon-green hover:bg-neon-green/10 text-left transition-all group">
                  <span className="text-xl mr-3">3️⃣</span>
                  <span className="text-gray-300 group-hover:text-white font-medium">Future Booking <span className="text-gray-500 text-sm block mt-1">(2 ya usse zyada din baad)</span></span>
                </button>
              </motion.div>
            )}

            {step === 'sameday_form' && (
              <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} onSubmit={handleSameDaySubmit} className="space-y-4">
                <h3 className="text-xl font-display font-bold text-neon-blue mb-4">Aaj Ka Booking</h3>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Naam</label>
                  <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-blue" placeholder="Aapka naam" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Kitne players</label>
                  <input required type="number" name="players" min="1" value={formData.players} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-blue" placeholder="Number of players" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Kaunsa time slot chahiye</label>
                  <input required type="text" name="timeSlot" value={formData.timeSlot} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-blue" placeholder="e.g. 5:00 PM - 6:00 PM" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Approx arrival time</label>
                  <input required type="time" name="arrivalTime" value={formData.arrivalTime} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-blue [color-scheme:dark]" />
                </div>
                <div className="p-3 bg-neon-blue/10 border border-neon-blue/30 rounded-lg text-sm text-neon-blue mt-4">
                  <strong>Note:</strong> Same day booking FINAL tabhi hogi jab owner confirm karega.
                </div>
                <button type="submit" className="w-full py-3.5 mt-2 bg-[#25D366] text-white rounded-xl font-bold flex justify-center items-center gap-2 hover:bg-[#20b858] transition-colors shadow-[0_0_15px_rgba(37,211,102,0.3)]">
                  <MessageCircle className="w-5 h-5" /> Send Request on WhatsApp
                </button>
              </motion.form>
            )}

            {step === 'future_form' && (
              <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} onSubmit={handleFutureSubmit} className="space-y-4">
                <h3 className="text-xl font-display font-bold text-neon-purple mb-4">Advance Booking</h3>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Naam</label>
                  <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-purple" placeholder="Aapka naam" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Date</label>
                  <input required type="date" name="date" min={new Date(Date.now() + 86400000).toISOString().split('T')[0]} value={formData.date} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-purple [color-scheme:dark]" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Time Slot</label>
                  <input required type="text" name="timeSlot" value={formData.timeSlot} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-purple" placeholder="e.g. 5:00 PM - 6:00 PM" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Kitne players</label>
                  <input required type="number" name="players" min="1" value={formData.players} onChange={handleChange} className="w-full bg-black border border-white/20 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-neon-purple" placeholder="Number of players" />
                </div>
                <div className="p-3 bg-neon-red/10 border border-neon-red/30 rounded-lg text-sm text-neon-red mt-4">
                  <strong>⚠️ Important:</strong> Slot confirm karne ke liye advance payment zaroori hai. Please 15 minutes ke andar payment kare. Payment receive hone ke baad hi slot block hoga.
                </div>
                <button type="submit" className="w-full py-3.5 mt-2 bg-[#25D366] text-white rounded-xl font-bold flex justify-center items-center gap-2 hover:bg-[#20b858] transition-colors shadow-[0_0_15px_rgba(37,211,102,0.3)]">
                  <MessageCircle className="w-5 h-5" /> Send Request on WhatsApp
                </button>
              </motion.form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
