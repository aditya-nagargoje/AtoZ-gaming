import { motion } from 'motion/react';
import { Clock, Gamepad2, MessageCircle } from 'lucide-react';

export default function Pricing() {
  const openWhatsApp = () => {
    window.dispatchEvent(new CustomEvent('open-booking-modal'));
  };

  return (
    <section id="pricing" className="py-24 bg-dark-surface relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-display font-bold text-white mb-4 uppercase tracking-wider"
          >
            Simple <span className="text-neon-green text-glow-green">Pricing</span>
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-neon-green mx-auto rounded-full box-glow-green"
          ></motion.div>
          <p className="mt-6 text-gray-400 max-w-2xl mx-auto text-lg">
            No hidden charges, no complicated plans. Just pure gaming fun at pocket-friendly rates.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* 30 Mins Plan */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-black/60 rounded-3xl p-8 backdrop-blur-md border-2 border-neon-blue box-glow-blue text-center relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
              <Clock className="w-24 h-24 text-neon-blue" />
            </div>
            <h3 className="text-2xl font-display font-bold uppercase tracking-wide mb-4 text-white relative z-10">
              Quick Session
            </h3>
            <div className="flex items-baseline justify-center gap-2 mb-6 relative z-10">
              <span className="text-6xl font-display font-black text-neon-blue text-glow-blue">₹50</span>
            </div>
            <p className="text-xl text-gray-300 font-medium mb-8 relative z-10">30 Minutes (1 Player)</p>
            
            <button
              onClick={openWhatsApp}
              className="w-full py-4 rounded-xl font-display font-bold uppercase tracking-wider bg-neon-blue text-black hover:bg-white transition-all duration-300 flex items-center justify-center gap-2 relative z-10"
            >
              <MessageCircle className="w-5 h-5" /> Book Slot
            </button>
          </motion.div>

          {/* 1 Hour Plan */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-black/60 rounded-3xl p-8 backdrop-blur-md border-2 border-neon-purple box-glow-purple text-center relative overflow-hidden group"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-neon-purple text-white px-6 py-1.5 rounded-b-xl text-sm font-bold uppercase tracking-wider z-20">
              Best Value
            </div>
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
              <Gamepad2 className="w-24 h-24 text-neon-purple" />
            </div>
            <h3 className="text-2xl font-display font-bold uppercase tracking-wide mb-4 text-white relative z-10 mt-4">
              Full Session
            </h3>
            <div className="flex items-baseline justify-center gap-2 mb-6 relative z-10">
              <span className="text-6xl font-display font-black text-neon-purple text-glow-purple">₹100</span>
            </div>
            <p className="text-xl text-gray-300 font-medium mb-8 relative z-10">1 Hour (1 Player)</p>
            
            <button
              onClick={openWhatsApp}
              className="w-full py-4 rounded-xl font-display font-bold uppercase tracking-wider bg-neon-purple text-white hover:bg-white hover:text-black transition-all duration-300 flex items-center justify-center gap-2 relative z-10"
            >
              <MessageCircle className="w-5 h-5" /> Book Slot
            </button>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-12 text-center bg-white/5 border border-white/10 rounded-xl p-6 max-w-2xl mx-auto backdrop-blur-sm"
        >
          <p className="text-gray-300 font-medium flex items-center justify-center gap-2">
            <span className="text-neon-green">✓</span> Controllers and comfortable seating included.
          </p>
          <p className="text-gray-300 font-medium flex items-center justify-center gap-2 mt-2">
            <span className="text-neon-green">✓</span> Multiplayer available at the shop. Bring your friends!
          </p>
        </motion.div>
      </div>
    </section>
  );
}
