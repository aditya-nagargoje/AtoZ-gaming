import { motion } from 'motion/react';

const games = [
  {
    id: 1,
    title: 'FIFA 24',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS5', 'PS4', 'Xbox'],
    color: 'blue',
  },
  {
    id: 2,
    title: 'Black Myth: Wukong',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS5', 'PC'],
    color: 'red',
  },
  {
    id: 3,
    title: 'Minecraft',
    image: 'https://images.unsplash.com/photo-1607853202273-797f1c22a38e?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS4', 'Xbox'],
    color: 'green',
  },
  {
    id: 4,
    title: 'Mortal Kombat 1',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS5', 'Xbox'],
    color: 'red',
  },
  {
    id: 5,
    title: 'WWE 2K24',
    image: 'https://images.unsplash.com/photo-1534423861386-85a16f5d13fd?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS4'],
    color: 'purple',
  },
  {
    id: 6,
    title: 'Forza Horizon 5',
    image: 'https://images.unsplash.com/photo-1614294149010-950b698f72c0?q=80&w=1000&auto=format&fit=crop',
    platforms: ['Xbox'],
    color: 'blue',
  },
  {
    id: 7,
    title: 'Resident Evil 4',
    image: 'https://images.unsplash.com/photo-1605901309584-818e25960b8f?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS5', 'PS4'],
    color: 'red',
  },
  {
    id: 8,
    title: 'Call of Duty: MW III',
    image: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?q=80&w=1000&auto=format&fit=crop',
    platforms: ['PS5', 'Xbox'],
    color: 'green',
  },
];

const getColorClasses = (color: string) => {
  switch (color) {
    case 'blue': return { border: 'hover:border-neon-blue', glow: 'hover:box-glow-blue', text: 'text-neon-blue' };
    case 'red': return { border: 'hover:border-neon-red', glow: 'hover:box-glow-red', text: 'text-neon-red' };
    case 'green': return { border: 'hover:border-neon-green', glow: 'hover:box-glow-green', text: 'text-neon-green' };
    case 'purple': return { border: 'hover:border-neon-purple', glow: 'hover:box-glow-purple', text: 'text-neon-purple' };
    default: return { border: 'hover:border-neon-blue', glow: 'hover:box-glow-blue', text: 'text-neon-blue' };
  }
};

export default function Games() {
  return (
    <section id="games" className="py-24 bg-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-display font-bold text-white mb-4 uppercase tracking-wider"
          >
            Featured <span className="text-neon-purple text-glow-purple">Titles</span>
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-neon-blue mx-auto rounded-full box-glow-blue"
          ></motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {games.map((game, index) => {
            const colors = getColorClasses(game.color);
            return (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`group relative overflow-hidden rounded-xl border-2 border-transparent bg-dark-surface transition-all duration-500 cursor-pointer ${colors.border} ${colors.glow}`}
              >
                {/* Image Container */}
                <div className="relative h-64 overflow-hidden">
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors duration-500 z-10"></div>
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6 z-20 bg-gradient-to-t from-black via-black/80 to-transparent translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-2xl font-display font-bold text-white mb-2 tracking-wide">
                    {game.title}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {game.platforms.map((platform) => (
                      <span
                        key={platform}
                        className={`text-xs font-bold px-2 py-1 rounded bg-white/10 backdrop-blur-md border border-white/20 uppercase tracking-wider ${colors.text}`}
                      >
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
