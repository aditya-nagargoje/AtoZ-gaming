import { motion } from 'motion/react';
import { MapPin, Phone, Clock, MessageCircle } from 'lucide-react';

export default function Contact() {
  const openWhatsApp = () => {
    window.dispatchEvent(new CustomEvent('open-booking-modal'));
  };

  return (
    <section id="contact" className="py-24 bg-dark-surface relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-display font-bold text-white mb-4 uppercase tracking-wider"
          >
            Visit <span className="text-neon-blue text-glow-blue">Us</span>
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-neon-blue mx-auto rounded-full box-glow-blue"
          ></motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="bg-black/50 p-6 rounded-2xl border border-white/5 flex items-start gap-4">
              <MapPin className="w-8 h-8 text-neon-red shrink-0 mt-1" />
              <div>
                <h4 className="text-xl font-display font-bold text-white mb-2">Shop Address</h4>
                <p className="text-gray-400 leading-relaxed">
                  Ato Z Gaming Zone<br />
                  Shop No. 5, Main Street, Near City Mall<br />
                  Pune, Maharashtra 411001
                </p>
              </div>
            </div>

            <div className="bg-black/50 p-6 rounded-2xl border border-white/5 flex items-start gap-4">
              <Clock className="w-8 h-8 text-neon-blue shrink-0 mt-1" />
              <div>
                <h4 className="text-xl font-display font-bold text-white mb-2">Opening Hours</h4>
                <p className="text-gray-400">Monday - Sunday</p>
                <p className="text-neon-blue font-medium text-glow-blue">10:00 AM - 11:00 PM</p>
              </div>
            </div>

            <div className="bg-black/50 p-6 rounded-2xl border border-white/5 flex items-start gap-4">
              <Phone className="w-8 h-8 text-neon-purple shrink-0 mt-1" />
              <div>
                <h4 className="text-xl font-display font-bold text-white mb-2">Call Us</h4>
                <p className="text-gray-400 text-lg">+91 70205 69018</p>
              </div>
            </div>

            <button
              onClick={openWhatsApp}
              className="w-full py-4 bg-[#25D366] text-white font-display font-bold text-lg rounded-xl uppercase tracking-wider shadow-[0_0_15px_rgba(37,211,102,0.3)] hover:scale-[1.02] transition-all duration-300 flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-6 h-6" /> Chat on WhatsApp
            </button>
          </motion.div>

          {/* Google Map */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="h-full min-h-[400px] rounded-2xl overflow-hidden border-2 border-white/10 relative"
          >
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121059.04711156077!2d73.78056541113032!3d18.524603553428803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf2e67461101%3A0x828d43bf9d9ee343!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1709280000000!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) contrast(1.2)' }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0"
            ></iframe>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
