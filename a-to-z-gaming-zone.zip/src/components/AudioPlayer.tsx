import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { motion } from 'motion/react';

export default function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // We use a placeholder audio URL for demo purposes.
    // In a real app, this would be a local asset like '/audio/bg-music.mp3'
    audioRef.current = new Audio('https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=cyberpunk-2099-10701.mp3');
    audioRef.current.loop = true;
    audioRef.current.volume = 0.3;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        // Handle autoplay policy
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <motion.button
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 2, duration: 0.5 }}
      onClick={togglePlay}
      className={`fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full flex items-center justify-center backdrop-blur-md border-2 transition-all duration-300 ${
        isPlaying 
          ? 'bg-neon-blue/20 border-neon-blue text-neon-blue box-glow-blue' 
          : 'bg-black/50 border-white/20 text-gray-400 hover:text-white hover:border-white/50'
      }`}
      aria-label="Toggle background music"
    >
      {isPlaying ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
      
      {/* Animated rings when playing */}
      {isPlaying && (
        <>
          <span className="absolute inset-0 rounded-full border border-neon-blue animate-ping opacity-75"></span>
          <span className="absolute inset-[-8px] rounded-full border border-neon-blue/50 animate-ping opacity-50" style={{ animationDelay: '0.2s' }}></span>
        </>
      )}
    </motion.button>
  );
}
