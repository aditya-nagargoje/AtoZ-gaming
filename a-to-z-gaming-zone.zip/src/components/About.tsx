import { motion } from 'motion/react';
import { Gamepad2, Wind, Users, IndianRupee } from 'lucide-react';

const features = [
  {
    icon: <Gamepad2 className="w-8 h-8 text-neon-blue" />,
    title: 'Latest PS5 & PS4 Games',
    description: 'Play all the trending and latest games like FIFA, GTA V, Cricket 24, and more on our high-end consoles.',
    glowClass: 'group-hover:box-glow-blue',
    textGlow: 'group-hover:text-glow-blue',
  },
  {
    icon: <Wind className="w-8 h-8 text-neon-purple" />,
    title: 'Comfortable AC Setup',
    description: 'Chill and play for hours in our fully air-conditioned gaming zone with comfortable seating.',
    glowClass: 'group-hover:box-glow-purple',
    textGlow: 'group-hover:text-glow-purple',
  },
  {
    icon: <Users className="w-8 h-8 text-neon-green" />,
    title: 'Multiplayer Friendly',
    description: 'Bring your squad! We have the perfect environment for multiplayer battles and co-op missions.',
    glowClass: 'group-hover:box-glow-green',
    textGlow: 'group-hover:text-glow-green',
  },
  {
    icon: <IndianRupee className="w-8 h-8 text-neon-red" />,
    title: 'Affordable Pricing',
    description: 'Enjoy premium gaming without breaking the bank. Simple, pocket-friendly hourly rates for everyone.',
    glowClass: 'group-hover:box-glow-red',
    textGlow: 'group-hover:text-glow-red',
  },
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-dark-surface relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-display font-bold text-white mb-4 uppercase tracking-wider"
          >
            Why Choose <span className="text-neon-blue text-glow-blue">Us?</span>
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-neon-purple mx-auto rounded-full box-glow-purple"
          ></motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`group bg-black/50 border border-white/5 p-8 rounded-2xl backdrop-blur-sm hover:border-transparent transition-all duration-500 ${feature.glowClass}`}
            >
              <div className="w-16 h-16 bg-white/5 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                {feature.icon}
              </div>
              <h3 className={`text-xl font-display font-bold text-white mb-3 transition-colors duration-300 ${feature.textGlow}`}>
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors duration-300">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
