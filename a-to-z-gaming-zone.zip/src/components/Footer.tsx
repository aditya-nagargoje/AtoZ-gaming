import { Gamepad2, Instagram, Facebook, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 pt-16 pb-8 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12 text-center md:text-left">
          <div className="flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 mb-4">
              <Gamepad2 className="w-8 h-8 text-neon-blue drop-shadow-[0_0_8px_rgba(0,243,255,0.8)]" />
              <span className="font-display font-bold text-2xl tracking-wider text-white text-glow-blue">
                Ato Z<span className="text-neon-purple text-glow-purple"> Gaming Zone</span>
              </span>
            </div>
            <p className="text-gray-400 max-w-xs leading-relaxed mb-6">
              Pune's favorite local gaming spot. Come play, relax, and enjoy the best games with your friends.
            </p>
            <div className="flex gap-4">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-neon-purple transition-all duration-300 hover:box-glow-purple group">
                  <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                </a>
              ))}
            </div>
          </div>

          <div className="flex flex-col items-center md:items-start">
            <h4 className="text-white font-display font-bold uppercase tracking-wider mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About', 'Games', 'Pricing', 'Gallery', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase()}`} className="text-gray-400 hover:text-neon-blue transition-colors duration-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col items-center md:items-start">
            <h4 className="text-white font-display font-bold uppercase tracking-wider mb-6">Contact Info</h4>
            <ul className="space-y-3 text-gray-400">
              <li>Shop No. 5, Main Street, Pune</li>
              <li>+91 70205 69018</li>
              <li className="text-neon-green font-medium">Open Daily: 10 AM - 11 PM</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Ato Z Gaming Zone. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
