import { useState, useEffect } from 'react';
import { Menu, X, Gamepad2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Games', href: '#games' },
  { name: 'Pricing', href: '#pricing' },
  { name: 'Gallery', href: '#gallery' },
  { name: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const openWhatsApp = () => {
    window.dispatchEvent(new CustomEvent('open-booking-modal'));
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/80 backdrop-blur-md border-b border-neon-blue/20 shadow-[0_0_15px_rgba(0,243,255,0.1)]'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('#home')}>
            <Gamepad2 className="w-8 h-8 text-neon-blue drop-shadow-[0_0_8px_rgba(0,243,255,0.8)]" />
            <span className="font-display font-bold text-xl tracking-wider text-white text-glow-blue">
              Ato Z<span className="text-neon-purple text-glow-purple"> Gaming</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="text-gray-300 hover:text-neon-blue font-medium transition-colors duration-300 relative group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-neon-blue transition-all duration-300 group-hover:w-full box-glow-blue"></span>
              </button>
            ))}
            <button 
              onClick={openWhatsApp}
              className="px-5 py-2 bg-[#25D366]/10 border-2 border-[#25D366] text-[#25D366] font-display font-semibold rounded-md hover:bg-[#25D366] hover:text-white transition-all duration-300 shadow-[0_0_10px_rgba(37,211,102,0.3)]"
            >
              WhatsApp Us
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-300 hover:text-neon-blue focus:outline-none"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/95 backdrop-blur-lg border-b border-neon-blue/20"
          >
            <div className="px-4 pt-2 pb-6 space-y-4 flex flex-col">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-gray-300 hover:text-neon-blue font-medium text-left text-lg py-2"
                >
                  {link.name}
                </button>
              ))}
              <button 
                onClick={openWhatsApp}
                className="w-full mt-4 px-5 py-3 bg-[#25D366]/10 border-2 border-[#25D366] text-[#25D366] font-display font-semibold rounded-md hover:bg-[#25D366] hover:text-white transition-all duration-300 shadow-[0_0_10px_rgba(37,211,102,0.3)] text-center"
              >
                WhatsApp Us
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
